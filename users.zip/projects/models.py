"""Модели приложения projects."""

from django.conf import settings
from django.db import models

STATUS_OPEN = 'open'
STATUS_CLOSED = 'closed'

STATUS_CHOICES = [
    (STATUS_OPEN, 'Открыт'),
    (STATUS_CLOSED, 'Закрыт'),
]


class Project(models.Model):
    """Модель pet-проекта."""

    name = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='owned_projects'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    github_url = models.URLField(blank=True)
    status = models.CharField(max_length=6, choices=STATUS_CHOICES, default=STATUS_OPEN)
    participants = models.ManyToManyField(
        settings.AUTH_USER_MODEL, blank=True, related_name='participated_projects'
    )

    class Meta:
        """Мета-настройки модели Project."""

        ordering = ['-created_at']

    def __str__(self):
        """Возвращает строковое представление."""
        return self.name
